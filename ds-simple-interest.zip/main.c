#include <stdio.h>
int main()
{
    float principal, rate, time, simpleInterest;
    printf("Enter Principal");
    scanf("%f", &principal);
    printf("Enter Rate");
    scanf("%f", &rate);
    printf("Enter Time");
    scanf("%f", &time);
    simpleInterest = (principal * rate * time) / 100;
    printf("Simple Interest = %.2f\n", simpleInterest);
    return 0;
}