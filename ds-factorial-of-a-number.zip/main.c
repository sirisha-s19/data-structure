#include<stdio.h>
int main()
{
    int n , i;
    long long fact=1;
    printf("enter a number ");
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        fact=fact*i;
    }
printf("factorial=%d",fact);
return 0;
}